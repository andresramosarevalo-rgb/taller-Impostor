package edu.co.ustavillavo.demo.repository;

import edu.co.ustavillavo.demo.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface RoomRepository extends JpaRepository<Room, UUID> {

    Optional<Room> findByCode(String code);
    Boolean existByCode(String code);
}
